/*
 * petla_cw4.cpp
 */


#include <iostream>
using namespace std;

int main(int argc, char **argv)
{
    int a;
    for(a=10;a<100;a++)
    if(a%6==0)
    cout<<a<<endl;
	return 0;
}

