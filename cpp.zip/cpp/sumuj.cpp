/*
 * Program pobiera i sumuje 10 liczb, wynik drukuje na ekranie.
 */


#include <iostream>
#include <math.h>

using namespace std;

int main(int argc, char **argv)
{
    int liczba1 , liczba2 , liczba3 , liczba4 , liczba5 , liczba6 , liczba7 , liczba8 , liczba9 , liczba10;
    cout << "Podaj pierwsza liczb:";
    cin >> liczba1;
    cout << "Podaj druga liczba:";
    cin >> liczba2;
    cout << "Podaj trzecia liczba:";
    cin >> liczba3;
    cout << "Podaj czwarta liczbe:";
    cin >> liczba4;
    cout << "Podaj piata liczba:";
    cin >> liczba5;
    cout << "Podaj szosta liczba:";
    cin >> liczba6;
    cout << "Podaj siodma liczba:";
    cin >> liczba7;
    cout << "Podaj osma liczba:";
    cin >> liczba8;
    cout << "Podaj dziewiata liczba:";
    cin >> liczba9;
    cout << "Podaj dziesiata liczba:";
    cin >> liczba10;
    
    cout << "Suma liczb:" << endl
         << liczba1 + liczba2 + liczba3 + liczba4 + liczba5 + liczba6 + liczba7 + liczba8 + liczba9 + liczba10 << endl; 
         
         return 0;
    }
    



