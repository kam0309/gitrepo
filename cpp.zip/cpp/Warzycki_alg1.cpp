/*
 * parzyste.cpp
 */


#include <iostream>

using namespace std;

int main(int argc, char **argv)
{   int a;
    cout <<"Podaj wartośc a:" <<endl;
    cin >> a;
    for(i = 1; i < 100; i += 2)
    int i = 2;
        if(a = i)
        cout << a <<"jest parzysta" << endl;
	else:
        if(i = i + 2)
    return 0;
}

