/*
 * dec2bin.cpp
 */


#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
    int liczba = 120;
    do{
        ;
        }while();
    
    }
{
	
	return 0;
}

