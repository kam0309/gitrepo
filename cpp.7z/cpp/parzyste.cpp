/*
 * parzyste.cpp
 */


#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
    int a;
    cout <<"Podaj wartośc a:" <<endl;
    cin >> a;
    if 0 < a 
	
	return 0;
}

