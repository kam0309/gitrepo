/*
 * hello.cpp
 */


#include <iostream>
#include <cmath>

using namespace std;

int main(int argc, char **argv)
{
    
    int r=0;
    
    
    cout << "Podaj promien:" << endl;
    cin >> r;
    cout << "Pole kola = " <<M_PI*r*r << endl;
    cout << "Obwod =" <<M_PI*r*2 << endl;
   
	return 0;
}

