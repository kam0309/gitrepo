/*
 * prostoka1.cpp
 */


#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
	int iloczyn , liczba;
    cout << "Podaj ilość liczb:" << endl;
    cin >> ilość;
    cout << endl;
    
    for(int i = 0;i , ilość;i++){
        cout <<"Podaj liczbę: " << i + 1<<endl;
        cin >>liczba; 
        }
    
	return 0;
}

