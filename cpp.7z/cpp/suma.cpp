/*
 * petla_for.cpp 
 */


#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
    int suma=0;
    for (int i = 10 ;i <=20; i++)
    suma = suma + i;
    cout << suma;
    
	return 0;
}

